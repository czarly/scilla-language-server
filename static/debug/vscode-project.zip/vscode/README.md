# Scilla Extension

This is a vscode extension to work wile scilla files.

http://www.scilla-lang.org


